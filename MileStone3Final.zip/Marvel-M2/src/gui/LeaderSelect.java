package gui;

import javax.swing.*;

public class LeaderSelect extends JPanel{
private Main main;
private JRadioButton c2;
private JRadioButton c1;
private JRadioButton c3;
private JLabel leaderSelect;

	public LeaderSelect(Main main,int[]team1) {
	leaderSelect=new JLabel("Please Select your Leader");
}
}
